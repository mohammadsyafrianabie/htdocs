<?php
include "koneksiku.php";
if(isset($_POST["submit"])){
$No_RM = $_POST['No_RM'];
$Nama_px = $_POST['Nama_px'];
$Alamat_px = $_POST['Alamat_px'];
$JK_px = $_POST['JK_px'];
$Tempatlhr_px = $_POST['Tempatlhr_px'];
$TanggalLhr_px = $_POST['TanggalLhr_px'];
$Agama_px = $_POST['Agama_px'];
$No_identitas = $_POST['No_identitas'];
$SP_px = $_POST['SP_px'];
$Nama_ayahSuami = $_POST['Nama_ayahSuami'];
$Nama_ibu = $_POST['Nama_ibu'];
$sql_cek = mysqli_query($conn, "SELECT * FROM pasien_tppri WHERE No_RM = '$No_RM'");
$query = "INSERT INTO pasien_tppri VALUES
            ('$No_RM', '$Nama_px', '$Alamat_px', '$JK_px', '$Tempatlhr_px', '$TanggalLhr_px', '$Agama_px', '$No_identitas', '$SP_px', '$Nama_ayahSuami', '$Nama_ibu')
            ";
if (mysqli_num_rows($sql_cek) > 0) {
echo "<script>alert('No. RM Sudah Ada!')</script>";
echo "<meta http-equiv='refresh' content='1 url=inputpasien.php'>";	
} else if ($query){
echo "<script>alert('Data Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=datapasien.php'>";
 mysqli_query($conn, $query);
 return mysqli_affected_rows($conn);
}else{
echo "<script>alert('Data Gagal Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=inputpasien.php'>";
}
}
?>
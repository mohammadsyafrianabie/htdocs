<?php
include "koneksiku.php";
if(isset($_POST["submit"])){
$ID_kamar = $_POST['ID_kamar'];
$nama_kamar = $_POST['nama_kamar'];
$kelas_kamar = $_POST['kelas_kamar'];
$bed = $_POST['bed'];

$query = "INSERT INTO kamar_tppri VALUES
            ('$ID_kamar', '$nama_kamar', '$kelas_kamar', '$bed')
            ";
 if ($query){
echo "<script>alert('Data Berhasil Diedit')</script>";
echo "<meta http-equiv='refresh' content='1 url=kamar.php'>";
 mysqli_query($conn, $query);
 return mysqli_affected_rows($conn);
}else{
echo "<script>alert('Data Gagal Diedit')</script>";
echo "<meta http-equiv='refresh' content='1 url=kamar.php'>";
}
}
}
?>
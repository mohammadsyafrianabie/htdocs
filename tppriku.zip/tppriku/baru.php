<?php
include "koneksiku.php";
  if(isset($_REQUEST['getID_kamar'])){
 $query1=mysqli_query($conn, "SELECT max(ID_pendaftaran) as ID_pendaftaran FROM pendaftaran_ri WHERE ID_kamar='".$_GET['ID_kamar']."'");
      while ($data_kamar_tppri=mysql_fetch_array($query1)) {
        $query1_bed=mysqli_query("SELECT * FROM kamar_tppri where ID_kamar='".$_GET['ID_kamar']."'");
        $data_bed=mysqli_fetch_array($query1_bed);
        //$pil = 1;
        //$bed=mysqli_query("UPDATE kamar_tppri SET kamar_tppri.bed= kamar_tppri.bed - 1 where ID_kamar='".$_GET['getKamar_pilihan']."' ");
        $bed = "UPDATE kamar_tppri SET bed= bed - 1 where ID_kamar='".$_GET['ID_kamar']."' ";
       }
   }

?>
<?php

include "koneksiku.php";
// massukan data ke transaksi obat
if (isset($_POST["Kamar_pilihan"])) 
			{
				
					$product_details = mysqli_query($conn, "SELECT * FROM kamar_tppri");
					$count = 0;

				$pil = 1;

					$ID_kamar = $_POST["ID_kamar"][$count];
					$update_bed = $product_details['bed'] - $pil[$count];

					// update stok obat
					$update_query = "
					UPDATE kamar_tppri
					SET bed = '".$update_bed."'
					WHERE ID_kamar = '".$ID_kamar."'
					";
					$statement = $conn->prepare($update_query);
					$statement->execute();
					// update stok obat
				}
?>
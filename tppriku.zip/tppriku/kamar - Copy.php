<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION["Login"])){
echo "<script>alert('Anda Belum Melakukan Login')</script>";
echo "<meta http-equiv='refresh' content='1 url=menulogin.php'>";
exit;
}
include "koneksiku.php";
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>RS Bina Sehat</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="assets/css/main.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="assets/js/hover.zoom.js"></script>
    <script src="assets/js/hover.zoom.conf.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  
  
  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="pembuka.php">Pendaftaran Rawat Inap</a>
        </div>
        <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
      <li><a href="inputpasien.php">PASIEN BARU</a></li>
      <li><a href="datapasien.php">DATA PASIEN</a></li>
      <li><a href="kamar.php">DATA KAMAR</a></li>      
      <li><a href="pendaftaran.php">PENDAFTARAN RI</a></li>
      <li><a href="laporanpasien.php">LAPORAN RI</a></li>
      <li><a href="logout.php">LOG OUT</a></li>

          </ul>
        </div><!--/.nav-collapse -->
      </div> 
    </div>
  <div id="body"> </untuk mengisi form atau isian yang akan diinputkan/>
    <form method="post" name="kamar" action="proses_datakamar.php" action="proses_pendafataran.php">
    <table border=0 align="center" cellpadding=5 cellspacing=0>
    <tr>
    <td colspan=3><center><font size=5>Isi Data Kamar Baru</font></center></td>
    </tr>
    <tr>
    <td>Kode Kamar</td><td>:</td><td><input type="text" name="ID_kamar" class = form-control required></td>
    </tr>
    <tr>
    <td>Nama Kamar</td><td>:</td><td><input type="text" name="nama_kamar" class = form-control required></td>
    </tr>
    <tr>
    <td>Kelas Kamar</td><td>:</td><td><input type="text" name="kelas_kamar" class = form-control required></td>
    </tr>
    <tr>
    <td>Persediaan Bed</td><td>:</td><td><input type="number" name="bed" class = form-control required></td>
    </tr>
    <tr>
    <td colspan=2>&nbsp;</td>
    <td><input type="submit" name="submit" value="Simpan" class ="btn btn"></td>
    </tr>
    </table>
    </form>
  </div>
  <div id="body" align="center">
     <?php
     echo "<h1>Detail Data Kamar</h1> ","<br>";
     ?>
     
     <?php 
     include "koneksiku.php"; 

    function query($query){
  global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while($row = mysqli_fetch_assoc($result)){
      $rows[] = $row;
    }
    return $rows;
}

 $kamar_tppri = query("SELECT * FROM kamar_tppri") ?>
 <table border="1" cellpadding="10" cellspacing="0" >
          <tr>
            <th>ID kamar</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Persediaan Bed</th>
          </tr>
       <?php foreach($kamar_tppri as $row): ?>
          <tr>
            <th><?= $row["ID_kamar"];?></th>
            <td><?= $row["nama_kamar"];?></td>
            <td><?= $row["kelas_kamar"];?></td>
            <td><?= $row["bed"];?></td>
          </tr>
      <?php endforeach; ?>
        </tbody>
      </table>
    </div>
</body>
</html>
        
        </div><!-- /col-lg-8 -->
      </div><!-- /row -->
      </div> <!-- /container -->
  </div><!-- /ww -->
  
    
<!-- +++++ Welcome Section +++++ -->
  <div id="ww">
      <div class="container">
      <div class="row">
        

        
      </div><!-- /row -->
      </div> <!-- /container -->
  </div><!-- /ww -->
  
  
  <!-- +++++ Footer Section +++++ -->
  
  <div id="footer">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-4">
          <h4>RS Bina Sehat</h4>
        </div><!-- /col-lg-4 -->
      
      </div>
    
    </div>
  </div>
  

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>

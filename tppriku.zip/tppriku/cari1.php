<?php

include "koneksiku.php";
if (isset($_GET['masuk'])) {

        $masuk = $_GET['masuk'];

        $queryl = mysqli_query($conn, "SELECT ID_kamar, nama_kamar, kelas_kamar FROM kamar_tppri WHERE ID_kamar LIKE '%$input%'"); //query mencari hasil search

        if ($query1 === FALSE) {

    die(mysqli_error());

}

        $keluaran = mysqli_num_rows($query1);

        if ($keluaran > 0)

        {

            while ($data1 = mysqli_fetch_row($query1)) {

            ?>

            <a href="javascript:autoInsert('<?=$data1[0]?>','<?=$data1[1]?>','<?=$data1[2]?>');"><?=$data1[0]?><br> <!--- hasil -->

            <?php

            }    

        }

    } 
?>
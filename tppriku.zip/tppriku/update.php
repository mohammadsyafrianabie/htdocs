<?php
include "koneksiku.php";
  $bed=mysqli_query("UPDATE kamar_tppri SET kamar_tppri.bed= kamar_tppri.bed - 1 where ID_kamar='".$_GET['getKamar_pilihan']."' ");
>?
<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION["Login"])){
echo "<script>alert('Anda Belum Melakukan Login')</script>";
echo "<meta http-equiv='refresh' content='1 url=menulogin.php'>";
exit;
}
include "koneksiku.php";
?>

<?php
if (isset($_POST['submit'])){

   $query =mysqli_query($conn, "INSERT INTO pendaftaran_ri(ID_pendaftaran,nama,no_rm,Noruang_pilihan,Tanggal_daftar,Asal_px) VALUES
            ("."'".$_POST['ID_pendaftaran']."','".$_POST['nama']."','".$_POST['no_rm']."','".$_POST['Noruang_pilihan']."','".$_POST['Tanggal_daftar']."','".$_POST['Asal_px']."') ");
    $a=(mysqli_query($conn,"UPDATE kamar_tppri set bed= bed - 1 WHERE ID_kamar='".$_POST['Noruang_pilihan']."'"));

    echo '
    <script>alert("Barang ditambahkan !");window.location="pendaftaran.php"</script>
    ';
}

?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>RS Bina Sehat</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="assets/css/main.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="assets/js/hover.zoom.js"></script>
    <script src="assets/js/hover.zoom.conf.js"></script>

    <script language="JavaScript">

    var ajaxRequest;

    function getAjax() { //fungsi untuk mengecek AJAX pada browser

        try {

            ajaxRequest = new XMLHttpRequest();

        } catch (e) {

            try {

                ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");

            }

            catch (e) {

                try {

                    ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");

                } catch (e) {

                    alert("Your browser broke!");

                    return false;

                }

            }

        }

    }

    function autoComplete() { //fungsi menangkap input search dan menampilkan hasil search

        getAjax();

        input = document.getElementById('inputan').value;

        if (input == "") {

            document.getElementById("hasil").innerHTML = "";


        }

        else {

            ajaxRequest.open("GET","cari.php?input="+input);

            ajaxRequest.onreadystatechange = function() {

                document.getElementById("hasil").innerHTML = ajaxRequest.responseText;


            }

          
            ajaxRequest.send(null);

        }

    }

    function autoInsert(No_RM, Nama_px) { //fungsi mengisi input text dengan hasil pencarian yang dipilih

        document.getElementById("inputan").value = No_RM;

        document.getElementById("nama").value = Nama_px;

        document.getElementById("hasil").innerHTML = "";
    }

</script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>


  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="pembuka.php">Pendaftaran Rawat Inap</a>
        </div>
        <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
      <li><a href="inputpasien.php">PASIEN BARU</a></li>
      <li><a href="datapasien.php">DATA PASIEN</a></li>
      <li><a href="kamar.php">DATA KAMAR</a></li>      
      <li><a href="pendaftaran.php">PENDAFTARAN RI</a></li>
      <li><a href="laporanpasien.php">LAPORAN RI</a></li>
      <li><a href="logout.php">LOG OUT</a></li>


          </ul>
        </div><!--/.nav-collapse -->
      </div> 
    </div>
    <div id="ww">
      <div class="container">
      <div class="row">

<div id="body"> </untuk mengisi form atau isian yang akan diinputkan/>
    <form method="post" >
    <table border=0 align="center" cellpadding=4 cellspacing=0>
    <tr>
    <td colspan=3><center><font size=6>Pendaftaran Pasien Rawat Inap</font></center></td>
    </tr>
    <tr>
    <td>No. Pendaftaran</td><td>:</td><td>
       <?php 
         
          $c=mysqli_query($conn, "SELECT * FROM pendaftaran_ri");
          while ($d = mysqli_fetch_array($c)){
            $no=$d['ID_pendaftaran'];
            }
          ?>
    <input  type=text class = form-control name="ID_pendaftaran" value="<?php echo $no; ?>" readonly></td>
    </tr>
    <tr>
    <td>Nama</td><td>:</td><td>
          <select name="nama" class = form-control id = "ID_kamar" required>
          <option value="">- Nama Pasien-</option>
          <?php 
         
          $a=mysqli_query($conn, "SELECT * FROM pasien_tppri;");
          while ($b = mysqli_fetch_array($a)){
            echo '<option value ="' .$b['Nama_px']. '">'. $b['Nama_px']. '</option>'; }
          ?>
      </select>
    </td>
    </tr>
    <tr>
    <td>Kamar Pilihan</td><td>:</td>
    <td>
      <select name="Noruang_pilihan" class = form-control id = "ID_kamar" required>
          <option value="">- Pilih Kamar-</option>
          <?php 
          $stok=0;
          $sql_kamar=mysqli_query($conn, "SELECT * FROM kamar_tppri WHERE bed > '$stok';");
          while ($data_kamar = mysqli_fetch_array($sql_kamar)){
            echo '<option value ="' .$data_kamar['ID_kamar']. '" value ="' .$data_kamar['nama_kamar']. '" value ="' .$data_kamar['kelas_kamar']. '"> '. $data_kamar['ID_kamar']. _. $data_kamar['nama_kamar']. _. $data_kamar['kelas_kamar']. '</option>'; }
          ?>
      </select>
    </td>
    </tr>
    <tr>
    <td>Tanggal Daftar</td><td>:</td><td><input type="date"  name="Tanggal_daftar" class = form-control required></td>
    </tr>
    <tr>
    <td>Asal Pasien</td><td>:</td>
    <td>
      <input type="radio"  name="Asal_px" value="IGD" required>IGD
      <input type="radio"  name="Asal_px" value="Poli Umum" required>Poli Umum
      <input type="radio"  name="Asal_px" value="Rujukan" required>Rujukan
    </td>
    </tr>
    
    <tr>
    <td colspan=2>&nbsp;</td>
    <td><input type="submit" name="submit" value="Simpan"></td>
    </tr>
    </table>
    </form>
  </div>
</body>

        </div><!-- /col-lg-8 -->
      </div><!-- /row -->
      </div> <!-- /container -->
  </div><!-- /ww -->
  <!-- +++++ Footer Section +++++ -->
  
  <div id="footer">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-4">
          <h4>RS Bina Sehat</h4>
        </div><!-- /col-lg-4 -->
      
      </div>
    
    </div>
  </div>
  

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>


<?php
include "koneksiku.php";




if(isset($_POST["submit"])){
$ID_pendaftaran = $_POST["ID_pendaftaran"];	
$nama = $_POST["nama"]; 
$no_rm = $_POST["no_rm"];	
$Noruang_pilihan= $_POST["Noruang_pilihan"];
$Tanggal_daftar = $_POST["Tanggal_daftar"];
$Asal_px = $_POST["Asal_px"];




	//if(isset($_REQUEST['getID_kamar'])){
        //$query_bed=mysqli_query($conn, "SELECT * FROM kamar_tppri where ID_kamar='".$data_kamar_tppri["ID_kamar"]."'");
        //$data_bed=mysqli_fetch_array($query_bed);
        //$pil = 1;
        //$bed=mysqli_query($conn, "UPDATE kamar_tppri SET bed_kamar_tppri=bed_kamar_tppri-'".$pil."' where ID_kamar='".$data_kamar_tppri["ID_kamar"]."' ");
       // echo "<script>alert('Data Terisi')</script>";
        //}
      //}

//$query1 = mysqli_query($conn, "SELECT kamar_tppri inner join pendaftaran_ri on kamar_tppri.ID_kamar=pendaftaran_ri.ID_kamar where kama") 
//$row = mysqli_fetch_array($sql)){
//if ($Kamar_pilihan = 'nama_kamar'){
	 //$bed=mysqli_query($conn, "UPDATE kamar_tppri inner join pendaftaran_ri on kamar_tppri.ID_kamar=pendaftaran_ri.ID_kamar SET kamar_tppri.bed=kamar_tppri.bed-1;");

//}

       // $query_bed=mysqli_query($conn, "SELECT * FROM kamar_tppri");
        //$data_bed=mysqli_fetch_array($query_bed);
        //$pil = 1;
        //$bed=mysqli_query($conn, "UPDATE kamar_tppri inner join pendaftaran_ri on kamar_tppri.ID_kamar=pendaftaran_ri.ID_kamar SET kamar_tppri.bed=kamar_tppri.bed-1 where ID_kamar = '$Kamar_pilihan';");
        //echo $bed;
if(empty($no_rm)){
echo "<script>alert('No RM belum diisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=pendaftaran.php'>";
}else{
        
$query = "INSERT INTO pendaftaran_ri VALUES
            ('','$ID_pendaftaran','$nama', '$no_rm', '$Noruang_pilihan', '$Tanggal_daftar', '$Asal_px')
            ";
if ($query){
//echo "<meta http-equiv='refresh' content='1 url=baru.php'>";
echo "<script>alert('Data Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=pendaftaran.php'>";
 mysqli_query($conn, $query);
 return mysqli_affected_rows($conn);
}else{
echo "<script>alert('Data Gagal Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=pendaftaran.php'>";
}
}
}
?>
<?php
// memanggil library FPDF
require('../phpfpdf/fpdf.php');
class PDF extends FPDF
{
// Page header
function Header()
{
    	// Logo
    	$this->Image('http://rsbinasehat.co.id/wp-content/uploads/2017/11/logo-rsbs.jpg', 10,8,30);
		$this->SetFont('Arial','B',18);
		//pindah ke posisi ke tengah untuk membuat judul
		$this->Cell(35);
		//judul
		$this->Cell(275,10,'RUMAH SAKIT BINA SEHAT',0,1,'C');
		$this->SetFont('Arial','B',10);
		$this->Cell(35);
		$this->Cell(275,5,'Jalan Jayanegara 7 Kaliwates - Jember - Jawa Timur',0,1,'C');
		$this->SetFont('Arial','B',10);
		$this->Cell(35);
		$this->Cell(275,5,'0331-422701, 421713, 427397',0,1,'C');
		$this->SetFont('Arial','B',10);
		$this->Cell(35);
		$this->Cell(275,5,'rs_binasehat@yahoo.com',0,1,'C');

		//pindah baris
		$this->Ln(35);
		//buat garis horisontal
}
}

$pdf = new PDF('l','mm','legal', '2');
// membuat halaman baru

$pdf->AliasNbPages();
$pdf->AddPage();

$tgl= ("Jember,"). date("d F Y");
// setting jenis font yang akan digunakan
//$pdf->SetFont('Arial','B',16);
// mencetak string 
$pdf->SetFont('Arial','B',15);
$pdf->Cell(350,10,'LAPORAN PENDAFTARAN RAWAT INAP',0,1,'C');
 
// Memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7,'',0,1);
$pdf->SetX(16); 
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,6,'No. RM',1,0);
$pdf->Cell(70,6,'Nama',1,0);
$pdf->Cell(85,6,'Alamat',1,0);
$pdf->Cell(26,6,'Jenis Kelamin',1,0);
$pdf->Cell(25,6,'ID Kamar',1,0);
$pdf->Cell(25,6,'Nama Kamar',1,0);
$pdf->Cell(25,6,'Kelas Kamar',1,0);
$pdf->Cell(27,6,'Tanggal Daftar',1,0);
$pdf->Cell(25,6,'Asal Pasien',1,1);
 
$pdf->SetFont('Arial','',10);

 
include 'koneksiku.php';
$sql = mysqli_query($conn, "SELECT * FROM pendaftaran_ri INNER JOIN pasien_tppri ON pasien_tppri.No_RM = pendaftaran_ri.No_RM  INNER JOIN kamar_tppri ON kamar_tppri.ID_kamar = pendaftaran_ri.ID_kamar ORDER BY Tanggal_daftar desc");
while ($row = mysqli_fetch_array($sql)){
	$pdf->SetX(16);
    $pdf->Cell(20,6,$row['No_RM'],1,0);
    $pdf->Cell(70,6,$row['Nama_px'],1,0);
    $pdf->Cell(85,6,$row['Alamat_px'],1,0);
    $pdf->Cell(26,6,$row['JK_px'],1,0);
    $pdf->Cell(25,6,$row['ID_kamar'],1,0);
    $pdf->Cell(25,6,$row['nama_kamar'],1,0);
    $pdf->Cell(25,6,$row['kelas_kamar'],1,0);
    $pdf->Cell(27,6,$row['Tanggal_daftar'],1,0); 
    $pdf->Cell(25,6,$row['Asal_px'],1,1);
}
 $pdf->Cell(325, 50, $tgl, '0', 1, 'R');
 
$pdf->Output();

?>
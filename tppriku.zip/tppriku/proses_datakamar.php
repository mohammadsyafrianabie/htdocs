<?php
include "koneksiku.php";
if(isset($_POST["submit"])){
$ID_kamar = $_POST['ID_kamar'];
$nama_kamar = $_POST['nama_kamar'];
$kelas_kamar = $_POST['kelas_kamar'];
$bed = $_POST['bed'];

$sql_cek = mysqli_query($conn, "SELECT * FROM kamar_tppri WHERE ID_kamar = '$ID_kamar'");
$query = "INSERT INTO kamar_tppri VALUES
            ('$ID_kamar', '$nama_kamar', '$kelas_kamar', '$bed')
            ";
 if (mysqli_num_rows($sql_cek) > 0) {
echo "<script>alert('Kode kamar Sudah Terdaftar!')</script>";
echo "<meta http-equiv='refresh' content='1 url=kamar.php'>";	
} else if ($query){
echo "<script>alert('Data Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=kamar.php'>";
 mysqli_query($conn, $query);
 return mysqli_affected_rows($conn);
}else{
echo "<script>alert('Data Gagal Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=kamar.php'>";
}
}
?>
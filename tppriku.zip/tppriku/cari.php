<?php

include "koneksiku.php";
    if (isset($_GET['input'])) {

        $input = $_GET['input'];
       

        $query = mysqli_query($conn, "SELECT No_RM, Nama_px FROM pasien_tppri WHERE No_RM LIKE '%$input%'"); //query mencari hasil search

        if ($query === FALSE) {

    die(mysqli_error());

}

        $hasil1 = mysqli_num_rows($query);

        if ($hasil1 > 0)

        {

            while ($data = mysqli_fetch_row($query)) {

            ?>

            <a href="javascript:autoInsert('<?=$data[0]?>','<?=$data[1]?>');"><?=$data[0]?><br> <!--- hasil -->

            <?php

            }    

        }

    }
?>
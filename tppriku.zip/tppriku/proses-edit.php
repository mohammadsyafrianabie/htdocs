<?php

include("koneksiku.php");

// cek apakah tombol simpan sudah diklik atau blum?
if(isset($_POST['simpan'])){

    // ambil data dari formulir
$ID_kamar = $_POST['ID_kamar'];
$nama_kamar = $_POST['nama_kamar'];
$kelas_kamar = $_POST['kelas_kamar'];
$bed = $_POST['bed'];

    // buat query update
    $sql = "UPDATE kamar_tppri SET nama_kamar='$nama_kamar', kelas_kamar='$kelas_kamar', bed='$bed' WHERE ID_kamar='$ID_kamar";
    $query = mysqli_query($db, $sql);

    // apakah query update berhasil?
    if( $query ) {
        // kalau berhasil alihkan ke halaman
        header('Location: kamar.php');
    } else {
        // kalau gagal tampilkan pesan
        die("Gagal menyimpan perubahan...");
    }


} else {
    die("Akses dilarang...");
}

?>

<?php
$conn = mysqli_connect("localhost","root","","tppri") or die ("Koneksi Database Gagal");

?>
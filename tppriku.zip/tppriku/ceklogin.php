<?php
session_start();
include "koneksiku.php";
if(isset($_POST["login"])){

$username = $_POST["username"];
$password = $_POST["password"];

$result = mysqli_query($conn, "select * from user where username='$username' and password='$password'");
if (mysqli_num_rows($result) === 1){
	$get = mysqli_fetch_array($result);
	$level = $get['Jabatan_user'];
	if ($level == "petugas"){
		$_SESSION["Login"] = true;
		echo "<script>alert('Log In Berhasil')</script>";
        echo "<meta http-equiv='refresh' content='1 url=pembuka.php'>";
	} else if ($level == "admin") {
		$_SESSION["Login"] = true;
       echo "<script>alert('Log In Berhasil')</script>";
       echo "<meta http-equiv='refresh' content='1 url=inputpetugas.php'>";
	} else {
echo "<script>alert('Username atau Password salah')</script>";
echo "<meta http-equiv='refresh' content='1 url=menulogin.php'>";
}
}
}
?>
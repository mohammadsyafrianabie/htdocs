<?php
include "koneksiku.php";
if(isset($_POST["submit"])){
$ID_user = $_POST['ID_user'];
$Nama_user = $_POST['Nama_user'];
$Jabatan_user = $_POST['Jabatan_user'];
$Alamat_user = $_POST['Alamat_user'];
$JK_user = $_POST['JK_user'];
$TempatLhr_user = $_POST['TempatLhr_user'];
$TanggalLhr_user = $_POST['TanggalLhr_user'];
$username = $_POST['username'];
$password = $_POST['password'];


$query = "INSERT INTO user VALUES
            ('$ID_user', '$Nama_user', '$Jabatan_user', '$Alamat_user', '$JK_user', '$TanggalLhr_user', '$TempatLhr_user', '$username', '$password')
            ";
 if ($query){
echo "<script>alert('Data Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=datapetugas.php'>";
 mysqli_query($conn, $query);
 return mysqli_affected_rows($conn);
}else{
echo "<script>alert('Data Gagal Terisi')</script>";
echo "<meta http-equiv='refresh' content='1 url=inputpetugas.php'>";
}
?>
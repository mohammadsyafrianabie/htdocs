<!DOCTYPE html>
<?php
session_start();
if(!isset($_SESSION["Login"])){
echo "<script>alert('Anda Belum Melakukan Login')</script>";
echo "<meta http-equiv='refresh' content='1 url=menulogin.php'>";
exit;
}
include "koneksiku.php";
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>RS Bina Sehat</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="assets/css/main.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="assets/js/hover.zoom.js"></script>
    <script src="assets/js/hover.zoom.conf.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  
  
  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-inverse navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="pembuka.php">Pendaftaran Rawat Inap</a>
        </div>
       <div class="navbar-collapse collapse">
        <ul class="nav navbar-nav navbar-right">
      <li><a href="inputpasien.php">PASIEN BARU</a></li>
      <li><a href="datapasien.php">DATA PASIEN</a></li>
      <li><a href="kamar.php">DATA KAMAR</a></li>      
      <li><a href="pendaftaran.php">PENDAFTARAN RI</a></li>
      <li><a href="laporanpasien.php">LAPORAN RI</a></li>
      <li><a href="logout.php">LOG OUT</a></li>



          </ul>
        </div><!--/.nav-collapse -->
      </div> 
    </div>
    <!-- +++++ Welcome Section +++++ -->
  <div id="ww">
      <div class="container">
      <div class="row">
        

        <div class="col-lg-8 col-lg-offset-2 centered">
          <h1>Laporan Pendaftaran RI</h1>
           <a href="print.php" class = "btn btn-info" class = "fa fa-print">Cetak</a>
                  </div><!-- /col-lg-8 -->
      </div><!-- /row -->
      </div> <!-- /container -->
  </div><!-- /ww -->
  
<body>
<div id="body" align="center">
      <table border="1" cellpadding="10" cellspacing="0" >
          <tr>
            <th>No. Pendaftaran</th>
            <th>No. RM</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Jenis Kelamin</th>
            <th>ID Kamar</th>
            <th>Nama Kamar</th>
            <th>Kelas Kamar</th>
            <th>Tanggal Daftar</th>
            <th>Asal Pasien</th>
          </tr>
     <?php $i = 1?>
     <?php 
 $query = mysqli_query($conn, "SELECT * FROM pendaftaran_ri INNER JOIN pasien_tppri ON pasien_tppri.Nama_px = pendaftaran_ri.nama INNER JOIN kamar_tppri ON kamar_tppri.ID_kamar = pendaftaran_ri.Noruang_pilihan ORDER BY Tanggal_daftar desc");
 while ($hasil = mysqli_fetch_array($query)) {
     ?>
          <tr>
            <td><?= $i;?></td>
            <td><?= $hasil["No_RM"];?></td>
            <td><?= $hasil["Nama_px"];?></td>
            <td><?= $hasil["Alamat_px"];?></td>
            <td><?= $hasil["JK_px"];?></td>
            <td><?= $hasil["ID_kamar"];?></td>
            <td><?= $hasil["nama_kamar"];?></td>
            <td><?= $hasil["kelas_kamar"];?></td>
            <td><?= $hasil["Tanggal_daftar"];?></td>
            <td><?= $hasil["Asal_px"];?></td>
          </tr>
       <?php $i++?>   
      <?php } ?>
        </tbody>
      </table>
    </div>
</body>
</html>

        
        </div><!-- /col-lg-8 -->
      </div><!-- /row -->
      </div> <!-- /container -->
  </div><!-- /ww -->
  
    
<!-- +++++ Welcome Section +++++ -->
  <div id="ww">
      <div class="container">
      <div class="row">
        

        
      </div><!-- /row -->
      </div> <!-- /container -->
  </div><!-- /ww -->
  
<!-- +++++ Footer Section +++++ -->
  
  <div id="footer">
    <div class="container">
      <div class="row">
        
        <div class="col-lg-4">
          <h4>RS Bina Sehat</h4>
        </div><!-- /col-lg-4 -->
      
      </div>
    
    </div>
  </div>
  

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>

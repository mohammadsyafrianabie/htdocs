-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Feb 2019 pada 05.23
-- Versi server: 10.1.31-MariaDB
-- Versi PHP: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tppri`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kamar_tppri`
--

CREATE TABLE `kamar_tppri` (
  `ID_kamar` char(6) NOT NULL,
  `nama_kamar` varchar(20) NOT NULL,
  `kelas_kamar` varchar(5) NOT NULL,
  `bed` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kamar_tppri`
--

INSERT INTO `kamar_tppri` (`ID_kamar`, `nama_kamar`, `kelas_kamar`, `bed`) VALUES
('KM-001', 'Dahlia', 'II', 0),
('KM-002', 'Melati', 'VIP', 5),
('KM-003', 'Mawar', 'VIP', 5),
('KM-004', 'Anggrek', 'III', 2),
('KM-005', 'Kamboja', 'vip', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien_tppri`
--

CREATE TABLE `pasien_tppri` (
  `No_RM` char(6) NOT NULL,
  `Nama_px` varchar(100) NOT NULL,
  `Alamat_px` varchar(100) NOT NULL,
  `JK_px` varchar(15) NOT NULL,
  `Tempatlhr_px` varchar(50) NOT NULL,
  `TanggalLhr_px` date NOT NULL,
  `Agama_px` varchar(15) NOT NULL,
  `No_identitas` char(20) NOT NULL,
  `SP_px` varchar(20) NOT NULL,
  `Nama_ayahSuami` varchar(100) NOT NULL,
  `Nama_ibu` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pasien_tppri`
--

INSERT INTO `pasien_tppri` (`No_RM`, `Nama_px`, `Alamat_px`, `JK_px`, `Tempatlhr_px`, `TanggalLhr_px`, `Agama_px`, `No_identitas`, `SP_px`, `Nama_ayahSuami`, `Nama_ibu`) VALUES
('123456', 'fatika', 'Jember', 'Perempuan', 'sidoarjo', '1999-11-12', 'Islam', '123485766', 'Kawin', 'Ayah', 'Ibu'),
('123654', 'Vina Fitria Rahayu', 'Jalan Ahmad Yang Gg Sutomo No.7', 'Perempuan', 'Probolinggo', '1999-01-12', 'Islam', '3578967543217', 'Belum Kawin', 'Ayah', 'Ibu'),
('127890', 'Bella', 'Lumajang', 'Perempuan', 'lumajang', '1999-02-08', 'Islam', '1324829', 'Belum Kawin', 'edward', 'maimunah'),
('345678', 'anggun', 'Malang', 'Perempuan', 'Situbondo', '1234-12-13', 'Islam', '456768', 'Belum Kawin', 'Ayah', 'Ibu'),
('456788', 'Liana', 'Jember', 'Perempuan', 'Situbondo', '2000-01-27', 'Islam', '12345678', 'Belum Kawin', 'Ayah', 'Ibu'),
('456793', 'Liana', 'Malang', 'Perempuan', 'sidoarjo', '0000-00-00', '', '', '', '', 'Ibu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftaran_ri`
--

CREATE TABLE `pendaftaran_ri` (
  `ID_pendaftaran` int(11) NOT NULL,
  `nama` varchar(220) NOT NULL,
  `no_rm` char(6) NOT NULL,
  `Noruang_pilihan` char(6) NOT NULL,
  `Kamar_pilihan` varchar(20) NOT NULL,
  `Kelas_pilihan` varchar(5) NOT NULL,
  `Tanggal_daftar` date NOT NULL,
  `Asal_px` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendaftaran_ri`
--

INSERT INTO `pendaftaran_ri` (`ID_pendaftaran`, `nama`, `no_rm`, `Noruang_pilihan`, `Kamar_pilihan`, `Kelas_pilihan`, `Tanggal_daftar`, `Asal_px`) VALUES
(7, '', '127890', 'KM-005', 'Kamboja', 'VIP', '2018-12-19', 'IGD'),
(15, '', '123456', 'KM-001', 'Dahlia', 'I', '2018-12-16', 'IGD'),
(16, '', '123456', 'KM-001', 'Dahlia', 'II', '2018-12-16', 'IGD'),
(17, 'ase', '121', 'KM-001', '', '', '2019-04-06', 'IGD'),
(18, 'Vina Fitria Rahayu', '', 'KM-001', '', '', '2019-02-06', 'IGD'),
(19, 'fatika', '', 'KM-001', '', '', '2019-02-06', 'Poli Umum'),
(20, 'fatika', '', 'KM-004', '', '', '2019-02-06', 'Poli Umum'),
(21, 'Vina Fitria Rahayu', '', 'KM-001', '', '', '2019-02-06', 'IGD'),
(22, 'Vina Fitria Rahayu', '', 'KM-004', '', '', '2019-02-06', 'Poli Umum'),
(23, 'Vina Fitria Rahayu', '', 'KM-004', '', '', '2019-02-06', 'Poli Umum'),
(24, 'Vina Fitria Rahayu', '', 'KM-004', '', '', '2019-02-06', 'Poli Umum'),
(25, 'Bella', '', 'KM-004', '', '', '2019-03-06', 'Poli Umum');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `ID_user` int(11) NOT NULL,
  `Nama_user` varchar(100) NOT NULL,
  `Jabatan_user` enum('admin','petugas') NOT NULL,
  `Alamat_user` varchar(100) NOT NULL,
  `JK_user` varchar(15) NOT NULL,
  `TempatLhr_user` varchar(50) NOT NULL,
  `TanggalLhr_user` date NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`ID_user`, `Nama_user`, `Jabatan_user`, `Alamat_user`, `JK_user`, `TempatLhr_user`, `TanggalLhr_user`, `username`, `password`) VALUES
(1, 'Vina', 'petugas', 'probolinggo', 'perempuan', 'probolinggo', '1999-01-12', 'vinaa', 'vina123'),
(2, 'Dani', 'admin', 'Probolinggo', 'laki-laki', 'Probolinggo', '1996-01-11', 'dani', 'dani123'),
(3, 'iftah', 'petugas', 'Malang', 'Perempuan', 'Probolinggo', '1998-06-26', 'iftah', 'iftah123'),
(4, 'ghozali', 'petugas', 'Malang', 'laki-laki', 'Probolinggo', '1998-12-10', 'ghozal', 'ghozal123'),
(5, 'Nugroho', 'petugas', 'Jember', 'laki-laki', 'Probolinggo', '9999-02-03', 'nugroho', '123'),
(6, 'mama', 'admin', 'Malang', 'Perempuan', 'Probolinggo', '1966-03-02', 'mama', 'mamaku'),
(7, 'ghozali', 'admin', 'Malang', '', '', '0000-00-00', 'halo', 'halo123'),
(8, 'Nugroho', 'petugas', 'Jember', 'laki-laki', '2006-12-12', '0000-00-00', 'nugroho1', 'nugroho123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kamar_tppri`
--
ALTER TABLE `kamar_tppri`
  ADD PRIMARY KEY (`ID_kamar`);

--
-- Indeks untuk tabel `pasien_tppri`
--
ALTER TABLE `pasien_tppri`
  ADD PRIMARY KEY (`No_RM`);

--
-- Indeks untuk tabel `pendaftaran_ri`
--
ALTER TABLE `pendaftaran_ri`
  ADD PRIMARY KEY (`ID_pendaftaran`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pendaftaran_ri`
--
ALTER TABLE `pendaftaran_ri`
  MODIFY `ID_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `ID_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
